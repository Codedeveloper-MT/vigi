from django.shortcuts import render, redirect
from django.http import JsonResponse
from .models import AccidentReport, CrimeReport  # Import your models
from .forms import IncidentReportForm
from django.utils import timezone
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth.views import LoginView
from django.contrib.auth.views import LogoutView
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect

def index(request):
    return render(request, 'index.html')


# View for the dashboard (showing reports and filtering by date)
def dashboard(request):
    accident_reports = AccidentReport.objects.all()
    crime_reports = CrimeReport.objects.all()

    context = {
        'accident_reports': accident_reports,
        'crime_reports': crime_reports
    }

    return render(request, 'user_upd.html', context)

# View to filter accident reports by date
def filter_accidents(request):
    if request.method == "GET":
        filter_date = request.GET.get('date', None)
        if filter_date:
            accident_reports = AccidentReport.objects.filter(date=filter_date)
        else:
            accident_reports = AccidentReport.objects.all()
        
        return JsonResponse({'accident_reports': list(accident_reports.values())})

# View to filter crime reports by date
def filter_crimes(request):
    if request.method == "GET":
        filter_date = request.GET.get('date', None)
        if filter_date:
            crime_reports = CrimeReport.objects.filter(date=filter_date)
        else:
            crime_reports = CrimeReport.objects.all()

        return JsonResponse({'crime_reports': list(crime_reports.values())})

def submit_incident(request):
    if request.method == 'POST':
        form = IncidentReportForm(request.POST, request.FILES)
        if form.is_valid():
            incident_type = form.cleaned_data['incident_type']
            report = form.save(commit=False)
            report.date = timezone.now()
            report.save()
            return JsonResponse({'status': 'success', 'message': 'Report submitted successfully.'})
        else:
            # Return form errors for debugging
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid form data.',
                'errors': form.errors
            })
    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'})


def incident_list(request):
    incidents = AccidentReport.objects.all()  # Get all incidents from the database
    return render(request, 'incident_list.html', {'incidents': incidents})

# # Login view
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            # Check the role of the user
            if user.is_police:
                return redirect('police_dashboard')  # Redirect to police dashboard
            elif user.is_paramedic:
                return redirect('paramedic_dashboard')  # Redirect to paramedic dashboard
            else:
                return redirect('user_dashboard')  # Redirect to user dashboard
        else:
            messages.error(request, "Invalid username or password.")
    
    return render(request, 'login.html')
# # Login view
# def login_view(request):
#     if request.method == 'POST':
#         username = request.POST['username']
#         password = request.POST['password']
#         role = request.POST['role']

#         user = authenticate(request, username=username, password=password)
#         if user is not None:
#             if hasattr(user, 'profile') and user.profile.role == role:
#                 auth_login(request, user)
#                 return redirect('dashboard')
#             else:
#                 messages.error(request, 'Invalid role for this user.')
#         else:
#             messages.error(request, 'Invalid username or password.')

#     return render(request, 'login.html')

# # Registration view
# def register_view(request):
#     if request.method == 'POST':
#         form = UserCreationForm(request.POST)
#         if form.is_valid():
#             form.save()
#             # Optionally, set a default role here or prompt the user to update later
#             return redirect('login')
#     else:
#         form = UserCreationForm()

#     return render(request, 'register.html', {'form': form})


class CustomLoginView(LoginView):
    template_name = 'login.html'
    
@login_required
def dashboard_view(request):
    return render(request, 'dashboard.html')

