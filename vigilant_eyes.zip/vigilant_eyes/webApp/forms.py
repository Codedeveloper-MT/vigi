from django import forms
from .models import AccidentReport, CrimeReport

class IncidentReportForm(forms.ModelForm):
    class Meta:
        model = AccidentReport
        fields = ['incident_type', 'description', 'location', 'image', 'video']
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Make location required but other fields optional
        self.fields['location'].required = True
        self.fields['description'].required = False
        self.fields['image'].required = False
        self.fields['video'].required = False
        
